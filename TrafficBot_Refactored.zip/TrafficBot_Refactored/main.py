"""
Traffic Bot - Professional Edition
Entry Point

ENHANCED: AI Engine Initialization & Dependency Check

Cara Pakai:
1. Install requirements: pip install -r requirements.txt
2. Jalankan: python main.py
"""

import sys
sys.dont_write_bytecode = True  # Disable .pyc creation

import sys
import os

# Tambahkan root directory ke path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_dependencies():
    """Check apakah semua dependencies sudah terinstall"""
    required_packages = [
        'selenium',
        'selenium_stealth',
        'webdriver_manager',
        'numpy',
        'pandas',
        'sklearn',
        'psutil'
    ]
    
    # Optional packages
    optional_packages = {
        'undetected_chromedriver': 'CAPTCHA Bypass (Recommended)',
        'python_anticaptcha': 'CAPTCHA Solver API (Optional)'
    }
    
    missing = []
    missing_optional = []
    
    # Check required
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    # Check optional
    for package, description in optional_packages.items():
        try:
            __import__(package)
        except ImportError:
            missing_optional.append(f"{package} ({description})")
    
    if missing:
        print("❌ Missing REQUIRED dependencies!")
        print(f"   Please run: pip install -r requirements.txt")
        print(f"\n   Missing packages: {', '.join(missing)}")
        return False
    
    if missing_optional:
        print("⚠️  Missing OPTIONAL dependencies:")
        for pkg in missing_optional:
            print(f"   - {pkg}")
        print("\n   Bot will work but some features may be limited.")
        print()
    
    return True


def initialize_ai_engine():
    """Initialize AI Engine"""
    try:
        from ai.intelligence_engine import ai_engine
        print("🤖 AI/ML Intelligence Engine initialized")
        print("   ✓ Behavioral Learning AI")
        print("   ✓ Pattern Detection AI")
        print("   ✓ Predictive CTR Optimization")
        print("   ✓ Anomaly Detection AI")
        print("   ✓ Proxy Intelligence AI")
        return True
    except Exception as e:
        print(f"⚠️  AI Engine initialization warning: {e}")
        print("   Bot will work with default settings.")
        return False


def main():
    """Main entry point"""
    print("=" * 60)
    print("🤖 TRAFFIC BOT - PROFESSIONAL EDITION")
    print("=" * 60)
    print()
    
    # Check dependencies
    print("🔍 Checking dependencies...")
    if not check_dependencies():
        input("\nPress Enter to exit...")
        return
    
    print("✅ All required dependencies installed!")
    print()
    
    # Initialize AI Engine
    print("🧠 Initializing AI Engine...")
    ai_initialized = initialize_ai_engine()
    print()
    
    # Import GUI (after dependency check)
    try:
        from ui.app import TrafficBotGUI
        from utils.logger import logger
        
        logger.info("Starting Traffic Bot GUI...")
        logger.info(f"AI Engine: {'Enabled' if ai_initialized else 'Disabled (using defaults)'}")
        
        # Create and run GUI
        print("🚀 Launching GUI...")
        print()
        
        app = TrafficBotGUI()
        app.mainloop()
        
        logger.info("Traffic Bot closed")
        
    except Exception as e:
        print(f"❌ Error starting application: {e}")
        import traceback
        traceback.print_exc()
        input("\nPress Enter to exit...")


if __name__ == "__main__":
    main()
