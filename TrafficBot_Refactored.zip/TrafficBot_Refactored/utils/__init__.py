"""
Utilities Module
Berisi logger dan helper functions
"""