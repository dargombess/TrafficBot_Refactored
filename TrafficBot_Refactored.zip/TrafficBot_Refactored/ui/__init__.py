"""
UI Module
Berisi GUI components dan styling
"""