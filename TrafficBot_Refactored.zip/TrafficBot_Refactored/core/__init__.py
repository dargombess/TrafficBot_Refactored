"""
Core Engine Module
Berisi worker, resource manager, dan AI engine
"""