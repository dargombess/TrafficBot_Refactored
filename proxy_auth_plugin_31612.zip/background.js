
        var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "46.224.52.65",
                    port: parseInt(39103)
                },
                bypassList: ["localhost"]
            }
        };
        
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        
        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "uKzg24IdDk",
                    password: "AEhRW7VvIe"
                }
            };
        }
        
        chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
        );
        