"""
Data Module
Berisi database dan history tracking
"""