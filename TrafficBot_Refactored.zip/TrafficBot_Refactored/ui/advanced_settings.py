"""
ui/advanced_settings.py - PROFESSIONAL TAB-BASED SETTINGS PANEL
Complete with ALL features + Deep Navigation + PRO Tab Styling + AUTO SAVE TO FILE
"""

import tkinter as tk
from tkinter import ttk, filedialog
from ui.styles import *
from bot_config import config
from config_saver import save_config_to_file


class AdvancedSettingsPanel(tk.Frame):
    """Professional Tab-Based Settings Panel with COMPLETE Features + Save to File"""
    
    def __init__(self, parent):
        super().__init__(parent, bg=COLOR_BG_MAIN)
        
        # State variables
        self.current_fp_mode = getattr(config, "FINGERPRINT_MODE", "Cortex")
        self.current_traffic_mode = getattr(config, "TRAFFIC_MODE", "Hybrid")
        self.current_captcha_service = getattr(config, "CAPTCHA_SOLVER_SERVICE", "2captcha")
        
        self._create_save_button_bar()
        self._create_professional_tabs()
    
    def _create_save_button_bar(self):
        """Create save button bar at bottom"""
        button_bar = tk.Frame(self, bg=COLOR_BG_PANEL, height=60)
        button_bar.pack(side="bottom", fill="x", padx=15, pady=15)
        button_bar.pack_propagate(False)
        
        # Save button
        save_btn = tk.Button(button_bar, text="💾 SAVE ALL SETTINGS TO FILE",
                            font=(FONT_FAMILY_PRIMARY, 11, "bold"),
                            bg=COLOR_SUCCESS, fg="white",
                            activebackground="#28a745",
                            relief="flat", cursor="hand2",
                            padx=30, pady=12,
                            command=self._save_config_to_file)
        save_btn.pack(side="right")
        
        # Info label
        self.save_status_label = tk.Label(button_bar, 
                                          text="Settings in memory (not saved to file)",
                                          font=(FONT_FAMILY_PRIMARY, 9),
                                          bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY)
        self.save_status_label.pack(side="left", padx=10)
    
    def _save_config_to_file(self):
        """Save current config to file"""
        try:
            success = save_config_to_file(config)
            if success:
                self.save_status_label.config(
                    text="✅ Settings saved to file successfully!",
                    fg=COLOR_SUCCESS
                )
                print("[SUCCESS] Config saved to bot_config.py")
                
                # Reset status after 3 seconds
                self.after(3000, lambda: self.save_status_label.config(
                    text="Settings in memory (not saved to file)",
                    fg=COLOR_TEXT_SECONDARY
                ))
            else:
                self.save_status_label.config(
                    text="❌ Failed to save settings!",
                    fg=COLOR_ACCENT_RED
                )
        except Exception as e:
            self.save_status_label.config(
                text=f"❌ Error: {str(e)}",
                fg=COLOR_ACCENT_RED
            )
            print(f"[ERROR] Save config failed: {e}")
    
    def _mark_unsaved(self):
        """Mark config as unsaved"""
        if hasattr(self, 'save_status_label'):
            self.save_status_label.config(
                text="⚠️ Unsaved changes (click SAVE button)",
                fg=COLOR_WARNING
            )
    
    def _create_professional_tabs(self):
        """Create professional styled tabs"""
        # Professional Tab Style (inspired by Tisocks_Hunter)
        style = ttk.Style()
        style.theme_use('default')
        
        # Notebook styling
        style.configure('TNotebook', 
                       background=COLOR_BG_MAIN, 
                       borderwidth=0,
                       tabmargins=[2, 5, 2, 0])
        
        # Tab styling - PRO VERSION
        style.configure('TNotebook.Tab',
                       background="#3a3a3a",
                       foreground="white",
                       padding=[15, 10],
                       font=(FONT_FAMILY_PRIMARY, 9, "bold"))
        
        # Selected tab gets CYAN color
        style.map('TNotebook.Tab',
                 background=[('selected', COLOR_ACCENT_CYAN)],
                 foreground=[('selected', 'black')],
                 expand=[('selected', [1, 1, 1, 0])])
        
        # Create notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        
        # Create all tabs
        self._create_files_tab()
        self._create_browser_tab()
        self._create_fingerprint_tab()
        self._create_proxy_tab()
        self._create_traffic_tab()
        self._create_behavior_tab()
        self._create_deep_navigation_tab()
        self._create_captcha_tab()
        self._create_ai_tab()
        self._create_performance_tab()
        self._create_operational_tab()
    
    def _create_files_tab(self):
        """Tab 1: Files Configuration"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="📁 Files")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Section header
        tk.Label(container, text="FILE CONFIGURATION",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        # File inputs
        self._add_file_row(container, "Article File:", "FILE_ARTICLES")
        self._add_file_row(container, "Proxy File:", "FILE_PROXIES")
        self._add_file_row(container, "Referrer File:", "FILE_REFERRERS")
    
    def _create_browser_tab(self):
        """Tab 2: Browser Settings"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🌐 Browser")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="BROWSER SETTINGS",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_switch_row(container, "Headless Mode (Run in background)", "HEADLESS")
        self._add_switch_row(container, "Use Undetected ChromeDriver", "USE_UNDETECTED_CHROME")
        
        # Browser Visibility
        self._add_radio_row(container, "Browser Visibility:", "BROWSER_VISIBILITY",
                           ["normal", "stealth", "ghost"])
        
        # User Agent Mode
        self._add_radio_row(container, "User Agent Mode:", "USER_AGENT_MODE",
                           ["Mixed", "Desktop Only", "Mobile Only"])
    
    def _create_fingerprint_tab(self):
        """Tab 3: Fingerprint & Identity"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🔐 Fingerprint")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="FINGERPRINT & IDENTITY",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        # Fingerprint Mode
        mode_frame = tk.Frame(container, bg=COLOR_BG_MAIN)
        mode_frame.pack(fill="x", pady=10)
        
        tk.Label(mode_frame, text="Fingerprint Mode:",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_PRIMARY).pack(side="left", padx=(0, 15))
        
        self.fp_mode_var = tk.StringVar(value=self.current_fp_mode)
        
        for mode in ["Cortex", "Pro", "JSON"]:
            tk.Radiobutton(mode_frame, text=mode, variable=self.fp_mode_var,
                          value=mode, command=self._on_fingerprint_change,
                          font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_BG_MAIN,
                          fg=COLOR_TEXT_PRIMARY, selectcolor=COLOR_INPUT_BG,
                          activebackground=COLOR_BG_MAIN).pack(side="left", padx=5)
        
        # Dynamic area
        self.fp_dynamic_area = tk.Frame(container, bg=COLOR_BG_MAIN)
        self.fp_dynamic_area.pack(fill="x", pady=10)
        
        self._refresh_fingerprint_ui()
        
        # Features
        tk.Label(container, text="Fingerprint Features:",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY).pack(anchor="w", pady=(15, 5))
        
        self._add_switch_row(container, "Canvas Fingerprinting", "CANVAS_FINGERPRINT")
        self._add_switch_row(container, "WebGL Fingerprinting", "WEBGL_FINGERPRINT")
        self._add_switch_row(container, "Audio Fingerprinting", "AUDIO_FINGERPRINT")
        self._add_switch_row(container, "WebRTC Protection", "WEBRTC_ENABLED")
        self._add_switch_row(container, "Timezone Synchronization", "TIMEZONE_SYNC")
    
    def _create_proxy_tab(self):
        """Tab 4: Proxy Configuration"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🌍 Proxy")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="PROXY CONFIGURATION",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_radio_row(container, "Proxy Type:", "PROXY_TYPE",
                           ["auto", "http", "https", "socks4", "socks5"])
        
        self._add_number_row(container, "Max Latency (ms):", "MAX_PROXY_LATENCY")
        self._add_switch_row(container, "Check Duplicate IP", "CHECK_DUPLICATE_IP")
        self._add_switch_row(container, "Proxy Intelligence AI", "PROXY_AI_ENABLED")
    
    def _create_traffic_tab(self):
        """Tab 5: Traffic Simulation"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🌐 Traffic")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="TRAFFIC SIMULATION",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        # Traffic Mode
        mode_frame = tk.Frame(container, bg=COLOR_BG_MAIN)
        mode_frame.pack(fill="x", pady=10)
        
        tk.Label(mode_frame, text="Traffic Mode:",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_PRIMARY).pack(side="left", padx=(0, 15))
        
        self.traffic_mode_var = tk.StringVar(value=self.current_traffic_mode)
        
        for mode in ["Hybrid", "External"]:
            tk.Radiobutton(mode_frame, text=mode, variable=self.traffic_mode_var,
                          value=mode, command=self._on_traffic_change,
                          font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_BG_MAIN,
                          fg=COLOR_TEXT_PRIMARY, selectcolor=COLOR_INPUT_BG,
                          activebackground=COLOR_BG_MAIN).pack(side="left", padx=5)
        
        # Dynamic area
        self.traffic_dynamic_area = tk.Frame(container, bg=COLOR_BG_MAIN)
        self.traffic_dynamic_area.pack(fill="x", pady=10)
        
        self._refresh_traffic_ui()
    
    def _create_behavior_tab(self):
        """Tab 6: Interaction Behavior"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🎯 Behavior")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="INTERACTION BEHAVIOR",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_range_row(container, "Scroll Count Range:", "SCROLL_MIN", "SCROLL_MAX")
        self._add_range_row(container, "Reading Time Range (seconds):", "DELAY_MIN", "DELAY_MAX")
        self._add_number_row(container, "Target CTR (%):", "TARGET_CTR")
        
        self._add_radio_row(container, "Mouse Movement Style:", "MOUSE_STYLE",
                           ["Human Curves", "Direct", "Random"])
    
    def _create_deep_navigation_tab(self):
        """Tab 7: Deep Navigation (NEW!)"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🚀 Deep Nav")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="DEEP NAVIGATION (Multi-page visits)",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_switch_row(container, "Enable Deep Navigation", "DEEP_NAVIGATION_ENABLED")
        
        # Navigation Depth Range
        depth_frame = tk.Frame(container, bg=COLOR_BG_MAIN)
        depth_frame.pack(fill="x", pady=10)
        
        tk.Label(depth_frame, text="Navigation Depth Range:",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY).pack(side="left", padx=(0, 15))
        
        tk.Label(depth_frame, text="Min Pages:", bg=COLOR_BG_MAIN,
                fg=COLOR_TEXT_SECONDARY).pack(side="left", padx=(0, 5))
        
        self.entry_min_pages = tk.Entry(depth_frame, width=5, font=(FONT_FAMILY_PRIMARY, 10),
                                        bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        self.entry_min_pages.insert(0, str(getattr(config, "MIN_PAGES", 2)))
        self.entry_min_pages.pack(side="left", padx=(0, 15))
        
        tk.Label(depth_frame, text="Max Pages:", bg=COLOR_BG_MAIN,
                fg=COLOR_TEXT_SECONDARY).pack(side="left", padx=(0, 5))
        
        self.entry_max_pages = tk.Entry(depth_frame, width=5, font=(FONT_FAMILY_PRIMARY, 10),
                                        bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        self.entry_max_pages.insert(0, str(getattr(config, "MAX_PAGES", 5)))
        self.entry_max_pages.pack(side="left")
        
        # Deep Navigation Behaviors (Collapsible sections)
        self._create_depth_level_section(container, "LANDING PAGE (Depth 0)", 0)
        self._create_depth_level_section(container, "LEVEL 1 (Depth 1)", 1)
        self._create_depth_level_section(container, "LEVEL 2 (Depth 2)", 2)
    
    def _create_depth_level_section(self, parent, title, depth):
        """Create collapsible depth level configuration"""
        section = tk.LabelFrame(parent, text=title, font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                               bg=COLOR_BG_PANEL, fg=COLOR_TEXT_PRIMARY, padx=10, pady=10)
        section.pack(fill="x", pady=5)
        
        # Scroll range
        row = tk.Frame(section, bg=COLOR_BG_PANEL)
        row.pack(fill="x", pady=3)
        
        tk.Label(row, text="Scroll Range:", bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_SECONDARY, width=20, anchor="w").pack(side="left")
        
        min_entry = tk.Entry(row, width=7, font=(FONT_FAMILY_PRIMARY, 9),
                            bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        min_entry.insert(0, str(getattr(config, f"SCROLL_MIN_D{depth}", 30)))
        min_entry.pack(side="left", padx=2)
        
        tk.Label(row, text="-", bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY).pack(side="left")
        
        max_entry = tk.Entry(row, width=7, font=(FONT_FAMILY_PRIMARY, 9),
                            bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        max_entry.insert(0, str(getattr(config, f"SCROLL_MAX_D{depth}", 60)))
        max_entry.pack(side="left", padx=2)
        
        # Read time range
        row2 = tk.Frame(section, bg=COLOR_BG_PANEL)
        row2.pack(fill="x", pady=3)
        
        tk.Label(row2, text="Read Time (s):", bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_SECONDARY, width=20, anchor="w").pack(side="left")
        
        min_read = tk.Entry(row2, width=7, font=(FONT_FAMILY_PRIMARY, 9),
                           bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        min_read.insert(0, str(getattr(config, f"READ_MIN_D{depth}", 20)))
        min_read.pack(side="left", padx=2)
        
        tk.Label(row2, text="-", bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY).pack(side="left")
        
        max_read = tk.Entry(row2, width=7, font=(FONT_FAMILY_PRIMARY, 9),
                           bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        max_read.insert(0, str(getattr(config, f"READ_MAX_D{depth}", 30)))
        max_read.pack(side="left", padx=2)
        
        # Click probability
        row3 = tk.Frame(section, bg=COLOR_BG_PANEL)
        row3.pack(fill="x", pady=3)
        
        tk.Label(row3, text="Click Probability (%):", bg=COLOR_BG_PANEL,
                fg=COLOR_TEXT_SECONDARY, width=20, anchor="w").pack(side="left")
        
        click_prob = tk.Entry(row3, width=7, font=(FONT_FAMILY_PRIMARY, 9),
                             bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        click_prob.insert(0, str(getattr(config, f"CLICK_PROB_D{depth}", 80)))
        click_prob.pack(side="left", padx=2)
    
    def _create_captcha_tab(self):
        """Tab 8: CAPTCHA Settings"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🔓 CAPTCHA")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="CAPTCHA BYPASS SETTINGS",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_switch_row(container, "Enable CAPTCHA Solver (API)", "CAPTCHA_SOLVER_ENABLED")
        
        # Service selection
        service_frame = tk.Frame(container, bg=COLOR_BG_MAIN)
        service_frame.pack(fill="x", pady=10)
        
        tk.Label(service_frame, text="CAPTCHA Service:",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_PRIMARY).pack(side="left", padx=(0, 15))
        
        self.captcha_service_var = tk.StringVar(value=self.current_captcha_service)
        
        for service in ["2captcha", "anticaptcha"]:
            tk.Radiobutton(service_frame, text=service, variable=self.captcha_service_var,
                          value=service, command=self._on_captcha_change,
                          font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_BG_MAIN,
                          fg=COLOR_TEXT_PRIMARY, selectcolor=COLOR_INPUT_BG,
                          activebackground=COLOR_BG_MAIN).pack(side="left", padx=5)
        
        # API Key
        self._add_text_row(container, "API Key:", "CAPTCHA_API_KEY", show="*")
        
        self._add_number_row(container, "Max Retry Attempts:", "CAPTCHA_MAX_RETRY")
        self._add_switch_row(container, "Auto Learn CAPTCHA Patterns (AI)", "AUTO_CAPTCHA_LEARN")
    
    def _create_ai_tab(self):
        """Tab 9: AI/ML Intelligence"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="🤖 AI/ML")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="AI/ML INTELLIGENCE ENGINE",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        # ALL 6 CHECKBOXES (same as old file)
        self._add_switch_row(container, "Enable AI Engine", "AI_ENABLED")
        self._add_switch_row(container, "Behavioral Learning AI", "AI_BEHAVIORAL_LEARNING")
        self._add_switch_row(container, "Pattern Detection AI", "AI_PATTERN_DETECTION")
        self._add_switch_row(container, "Predictive CTR Optimization", "AI_PREDICT_CTR")
        self._add_switch_row(container, "Anomaly Detection AI", "AI_ANOMALY_DETECTION")
        self._add_switch_row(container, "Proxy Intelligence AI", "AI_PROXY_INTELLIGENCE")
    
    def _create_performance_tab(self):
        """Tab 10: Performance & Resources"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="⚡ Performance")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="PERFORMANCE & RESOURCE BLOCKING",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        tk.Label(container, text="Resource Blocking (for speed):",
                font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY).pack(anchor="w", pady=(10, 5))
        
        self._add_switch_row(container, "Block Images", "BLOCK_IMAGES")
        self._add_switch_row(container, "Block CSS", "BLOCK_CSS")
        self._add_switch_row(container, "Block Fonts", "BLOCK_FONTS")
    
    def _create_operational_tab(self):
        """Tab 11: Operational Settings"""
        tab = tk.Frame(self.notebook, bg=COLOR_BG_MAIN)
        self.notebook.add(tab, text="⚙️ Operational")
        
        container = tk.Frame(tab, bg=COLOR_BG_MAIN)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(container, text="OPERATIONAL SETTINGS",
                font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN).pack(anchor="w", pady=(0, 15))
        
        self._add_number_row(container, "Max Retries:", "MAX_RETRIES")
        self._add_number_row(container, "Retry Delay (s):", "RETRY_DELAY")
        self._add_switch_row(container, "Parallel Processing", "PARALLEL_PROCESSING")
        self._add_switch_row(container, "In-Memory Cache", "IN_MEMORY_CACHE")
        self._add_switch_row(container, "Aggressive Stealth", "AGGRESSIVE_STEALTH")
    
    # ========== HELPER METHODS (WITH AUTO-SAVE FIX) ==========
    
    def _add_file_row(self, parent, label, config_key):
        """Add file selection row"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=5)
        
        tk.Label(row, text=label, font=(FONT_FAMILY_PRIMARY, 10),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY, width=18, anchor="w").pack(side="left")
        
        entry = tk.Entry(row, font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_INPUT_BG,
                        fg=COLOR_TEXT_PRIMARY, relief="flat")
        entry.pack(side="left", fill="x", expand=True, padx=5)
        entry.insert(0, getattr(config, config_key, ""))
        
        def browse():
            path = filedialog.askopenfilename(title=f"Select {label}",
                                             filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if path:
                entry.delete(0, tk.END)
                entry.insert(0, path)
                setattr(config, config_key, path)
                print(f"[CONFIG] {config_key} = {path}")
                self._mark_unsaved()
        
        tk.Button(row, text="📁", command=browse, font=(FONT_FAMILY_PRIMARY, 10),
                 bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat",
                 padx=8, cursor="hand2").pack(side="right")
    
    def _add_text_row(self, parent, label, config_key, show=None):
        """Add text input row with auto-save"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=5)
        
        tk.Label(row, text=label, font=(FONT_FAMILY_PRIMARY, 10),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY, width=18, anchor="w").pack(side="left")
        
        entry = tk.Entry(row, font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_INPUT_BG,
                        fg=COLOR_TEXT_PRIMARY, relief="flat", show=show)
        entry.pack(side="left", fill="x", expand=True, padx=5)
        entry.insert(0, getattr(config, config_key, ""))
        
        def on_change(event):
            value = entry.get()
            setattr(config, config_key, value)
            print(f"[CONFIG] {config_key} = {value if not show else '***'}")
            self._mark_unsaved()
        
        entry.bind('<FocusOut>', on_change)
        entry.bind('<Return>', on_change)
    
    def _add_switch_row(self, parent, label, config_key):
        """Add switch/checkbox row with auto-save"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=5)
        
        var = tk.BooleanVar(value=getattr(config, config_key, False))
        
        def on_toggle():
            value = var.get()
            setattr(config, config_key, value)
            print(f"[CONFIG] {config_key} = {value}")
            self._mark_unsaved()
        
        chk = tk.Checkbutton(row, text=label, variable=var,
                            font=(FONT_FAMILY_PRIMARY, 10),
                            bg=COLOR_BG_MAIN, fg=COLOR_TEXT_PRIMARY,
                            selectcolor=COLOR_INPUT_BG,
                            activebackground=COLOR_BG_MAIN,
                            activeforeground=COLOR_TEXT_PRIMARY,
                            command=on_toggle)
        chk.pack(side="left")
    
    def _add_radio_row(self, parent, label, config_key, options):
        """Add radio button row with auto-save"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=10)
        
        tk.Label(row, text=label, font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_PRIMARY).pack(side="left", padx=(0, 15))
        
        var = tk.StringVar(value=getattr(config, config_key, options[0]))
        
        def on_change():
            value = var.get()
            setattr(config, config_key, value)
            print(f"[CONFIG] {config_key} = {value}")
            self._mark_unsaved()
        
        for opt in options:
            tk.Radiobutton(row, text=opt, variable=var, value=opt,
                          command=on_change,
                          font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_BG_MAIN,
                          fg=COLOR_TEXT_PRIMARY, selectcolor=COLOR_INPUT_BG,
                          activebackground=COLOR_BG_MAIN).pack(side="left", padx=5)
    
    def _add_number_row(self, parent, label, config_key):
        """Add number input row with auto-save"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=5)
        
        tk.Label(row, text=label, font=(FONT_FAMILY_PRIMARY, 10),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY, width=25, anchor="w").pack(side="left")
        
        entry = tk.Entry(row, width=10, font=(FONT_FAMILY_PRIMARY, 10),
                        bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        entry.pack(side="left")
        entry.insert(0, str(getattr(config, config_key, 0)))
        
        def on_change(event):
            try:
                value = float(entry.get()) if '.' in entry.get() else int(entry.get())
                setattr(config, config_key, value)
                print(f"[CONFIG] {config_key} = {value}")
                self._mark_unsaved()
            except Exception as e:
                print(f"[ERROR] {config_key}: {e}")
        
        entry.bind('<FocusOut>', on_change)
        entry.bind('<Return>', on_change)
    
    def _add_range_row(self, parent, label, key_min, key_max):
        """Add range input row with auto-save"""
        row = tk.Frame(parent, bg=COLOR_BG_MAIN)
        row.pack(fill="x", pady=5)
        
        tk.Label(row, text=label, font=(FONT_FAMILY_PRIMARY, 10),
                bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY, width=25, anchor="w").pack(side="left")
        
        entry_min = tk.Entry(row, width=7, font=(FONT_FAMILY_PRIMARY, 10),
                            bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        entry_min.insert(0, str(getattr(config, key_min, 0)))
        entry_min.pack(side="left", padx=2)
        
        tk.Label(row, text="-", bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY).pack(side="left")
        
        entry_max = tk.Entry(row, width=7, font=(FONT_FAMILY_PRIMARY, 10),
                            bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat")
        entry_max.insert(0, str(getattr(config, key_max, 0)))
        entry_max.pack(side="left", padx=2)
        
        def on_change_min(event):
            try:
                value = int(entry_min.get())
                setattr(config, key_min, value)
                print(f"[CONFIG] {key_min} = {value}")
                self._mark_unsaved()
            except Exception as e:
                print(f"[ERROR] {key_min}: {e}")
        
        def on_change_max(event):
            try:
                value = int(entry_max.get())
                setattr(config, key_max, value)
                print(f"[CONFIG] {key_max} = {value}")
                self._mark_unsaved()
            except Exception as e:
                print(f"[ERROR] {key_max}: {e}")
        
        entry_min.bind('<FocusOut>', on_change_min)
        entry_min.bind('<Return>', on_change_min)
        entry_max.bind('<FocusOut>', on_change_max)
        entry_max.bind('<Return>', on_change_max)
    
    def _on_fingerprint_change(self):
        """Handle fingerprint mode change"""
        mode = self.fp_mode_var.get()
        setattr(config, "FINGERPRINT_MODE", mode)
        print(f"[CONFIG] FINGERPRINT_MODE = {mode}")
        self._mark_unsaved()
        self._refresh_fingerprint_ui()
    
    def _refresh_fingerprint_ui(self):
        """Refresh fingerprint UI based on mode"""
        for widget in self.fp_dynamic_area.winfo_children():
            widget.destroy()
        
        mode = self.fp_mode_var.get()
        
        if mode == "Cortex":
            tk.Label(self.fp_dynamic_area, text="✓ Using built-in Cortex Fingerprint Engine",
                    font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_BG_MAIN,
                    fg=COLOR_SUCCESS).pack(anchor="w", pady=5)
        elif mode == "Pro":
            self._add_file_row(self.fp_dynamic_area, "Pro License File:", "FINGERPRINT_PRO_FILE")
        elif mode == "JSON":
            row = tk.Frame(self.fp_dynamic_area, bg=COLOR_BG_MAIN)
            row.pack(fill="x", pady=5)
            
            tk.Label(row, text="JSON Folder:", font=(FONT_FAMILY_PRIMARY, 10),
                    bg=COLOR_BG_MAIN, fg=COLOR_TEXT_SECONDARY, width=18, anchor="w").pack(side="left")
            
            entry = tk.Entry(row, font=(FONT_FAMILY_PRIMARY, 9), bg=COLOR_INPUT_BG,
                            fg=COLOR_TEXT_PRIMARY, relief="flat")
            entry.pack(side="left", fill="x", expand=True, padx=5)
            entry.insert(0, getattr(config, "FINGERPRINT_FOLDER", ""))
            
            def browse():
                path = filedialog.askdirectory(title="Select JSON Folder")
                if path:
                    entry.delete(0, tk.END)
                    entry.insert(0, path)
                    setattr(config, "FINGERPRINT_FOLDER", path)
                    print(f"[CONFIG] FINGERPRINT_FOLDER = {path}")
                    self._mark_unsaved()
            
            tk.Button(row, text="📁", command=browse, font=(FONT_FAMILY_PRIMARY, 10),
                     bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, relief="flat",
                     padx=8, cursor="hand2").pack(side="right")
    
    def _on_traffic_change(self):
        """Handle traffic mode change"""
        mode = self.traffic_mode_var.get()
        setattr(config, "TRAFFIC_MODE", mode)
        print(f"[CONFIG] TRAFFIC_MODE = {mode}")
        self._mark_unsaved()
        self._refresh_traffic_ui()
    
    def _refresh_traffic_ui(self):
        """Refresh traffic UI based on mode"""
        for widget in self.traffic_dynamic_area.winfo_children():
            widget.destroy()
        
        mode = self.traffic_mode_var.get()
        
        if mode == "Hybrid":
            # Search/Social ratio slider
            row = tk.Frame(self.traffic_dynamic_area, bg=COLOR_BG_MAIN)
            row.pack(fill="x", pady=10)
            
            label_frame = tk.Frame(row, bg=COLOR_BG_MAIN)
            label_frame.pack(fill="x")
            
            search_label = tk.Label(label_frame, text="Search: 40%",
                                   font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                                   bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN)
            search_label.pack(side="left")
            
            social_label = tk.Label(label_frame, text="Social: 60%",
                                   font=(FONT_FAMILY_PRIMARY, 10, "bold"),
                                   bg=COLOR_BG_MAIN, fg="#3699ff")
            social_label.pack(side="right")
            
            var = tk.IntVar(value=getattr(config, "SEARCH_RATIO", 40))
            
            def on_change(val):
                search_pct = int(float(val))
                social_pct = 100 - search_pct
                search_label.config(text=f"Search: {search_pct}%")
                social_label.config(text=f"Social: {social_pct}%")
                setattr(config, "SEARCH_RATIO", search_pct)
                print(f"[CONFIG] SEARCH_RATIO = {search_pct}")
                self._mark_unsaved()
            
            slider = tk.Scale(row, from_=0, to=100, orient="horizontal", variable=var,
                            command=on_change, bg=COLOR_BG_MAIN, fg=COLOR_ACCENT_CYAN,
                            troughcolor=COLOR_INPUT_BG, highlightthickness=0,
                            showvalue=False, length=400)
            slider.pack(fill="x", pady=(10, 0))
        
        elif mode == "External":
            self._add_file_row(self.traffic_dynamic_area, "External Referrer File:", "FILE_REFERRERS")
    
    def _on_captcha_change(self):
        """Handle CAPTCHA service change"""
        service = self.captcha_service_var.get()
        setattr(config, "CAPTCHA_SOLVER_SERVICE", service)
        print(f"[CONFIG] CAPTCHA_SOLVER_SERVICE = {service}")
        self._mark_unsaved()
