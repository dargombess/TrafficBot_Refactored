"""
Bot Worker - The Brain of Traffic Bot
Menjalankan semua task dengan human-like behavior
ENHANCED: AI Integration + CAPTCHA Bypass + Deep Navigation + Undetected Chrome
"""

import time
import random
import os
import json
import zipfile
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

# Import undetected-chromedriver
try:
    import undetected_chromedriver as uc
    UNDETECTED_AVAILABLE = True
except ImportError:
    UNDETECTED_AVAILABLE = False
    print("⚠️ undetected-chromedriver not available, using standard selenium")

# Import Windows API for taskbar hide
try:
    import win32gui  # type: ignore
    import win32con  # type: ignore
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
    print("⚠️ pywin32 not available, taskbar hiding disabled")

from bot_config import config
from utils.logger import logger

# Import Deep Navigation Engine
try:
    from core.deep_navigation import DeepNavigationEngine
    DEEP_NAV_AVAILABLE = True
except ImportError:
    DEEP_NAV_AVAILABLE = False
    logger.warning("⚠️ Deep Navigation Engine not available")

# Import AI Engine
try:
    from ai.intelligence_engine import ai_engine
    AI_AVAILABLE = True
except ImportError:
    AI_AVAILABLE = False
    logger.warning("⚠️ AI Engine not available")


class BotWorker:
    """Worker untuk menjalankan single bot task dengan full features + AI + captcha bypass + deep navigation"""
    
    def __init__(self, worker_id: int):
        """
        Initialize worker
        
        Args:
            worker_id: ID unik untuk worker ini
        """
        self.worker_id = worker_id
        self.driver = None
        self.is_running = False
        
        # Proxy settings
        self.proxy = None
        self.proxy_host = None
        self.proxy_port = None
        self.proxy_user = None
        self.proxy_pass = None
        self.has_auth = False
        
        # State
        self.is_hidden = True
        self.fingerprint_data = None
        self.captcha_detected_count = 0
        self.browser_hwnd = None  # Windows handle untuk hide/show
        
        # AI-optimized behavior (will be set by AI if enabled)
        self.ai_scroll_count = None
        self.ai_delay = None
        self.ai_ctr = None
        
        # Deep Navigation Engine
        self.deep_nav = None
    
    def parse_proxy(self, proxy_str: str):
        """
        Parse proxy string
        
        Args:
            proxy_str: Proxy dalam format IP:PORT atau IP:PORT:USER:PASS
        """
        if not proxy_str:
            return
        
        parts = proxy_str.split(':')
        
        if len(parts) == 2:  # IP:PORT
            self.proxy_host = parts[0]
            self.proxy_port = parts[1]
            self.has_auth = False
        elif len(parts) == 4:  # IP:PORT:USER:PASS
            self.proxy_host = parts[0]
            self.proxy_port = parts[1]
            self.proxy_user = parts[2]
            self.proxy_pass = parts[3]
            self.has_auth = True
    
    def create_proxy_extension(self) -> str:
        """
        Create Chrome extension for proxy authentication
        
        Returns:
            Path ke extension zip file
        """
        if not self.has_auth:
            return None
        
        try:
            manifest_json = """
{
    "version": "1.0.0",
    "manifest_version": 3,
    "name": "Chrome Proxy",
    "permissions": [
        "proxy",
        "tabs",
        "unlimitedStorage",
        "storage",
        "webRequest",
        "webRequestAuthProvider"
    ],
    "host_permissions": [
        "<all_urls>"
    ],
    "background": {
        "service_worker": "background.js"
    }
}
"""
            
            background_js = f"""
var config = {{
    mode: "fixed_servers",
    rules: {{
        singleProxy: {{
            scheme: "http",
            host: "{self.proxy_host}",
            port: parseInt({self.proxy_port})
        }},
        bypassList: ["localhost"]
    }}
}};

chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});

chrome.webRequest.onAuthRequired.addListener(
    function(details) {{
        return {{
            authCredentials: {{
                username: "{self.proxy_user}",
                password: "{self.proxy_pass}"
            }}
        }};
    }},
    {{urls: ["<all_urls>"]}},
    ["blocking"]
);
"""
            
            plugin_file = f"proxy_auth_plugin_{self.worker_id}.zip"
            
            with zipfile.ZipFile(plugin_file, 'w') as zp:
                zp.writestr("manifest.json", manifest_json)
                zp.writestr("background.js", background_js)
            
            return plugin_file
            
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: Error creating proxy extension - {e}")
            return None
    
    def load_fingerprint(self):
        """Load fingerprint based on config mode"""
        fp_mode = getattr(config, 'FINGERPRINT_MODE', 'Cortex')
        
        if fp_mode == "JSON":
            json_folder = getattr(config, 'FINGERPRINT_FOLDER', '')
            if json_folder and os.path.exists(json_folder):
                try:
                    files = [f for f in os.listdir(json_folder) if f.endswith('.json')]
                    if files:
                        chosen_file = random.choice(files)
                        with open(os.path.join(json_folder, chosen_file), 'r', encoding='utf-8') as f:
                            self.fingerprint_data = json.load(f)
                        logger.info(f"Worker {self.worker_id}: Loaded fingerprint from {chosen_file}")
                except Exception as e:
                    logger.error(f"Worker {self.worker_id}: Error loading fingerprint - {e}")
    
    def _hide_browser_from_taskbar(self):
        """Hide browser from taskbar using Windows API (BAS-Style) - IMPROVED VERSION"""
        if not WIN32_AVAILABLE:
            logger.warning(f"Worker {self.worker_id}: pywin32 not available, cannot hide from taskbar")
            return
        
        try:
            # Get Chrome window handle
            def callback(hwnd, hwnds):
                if win32gui.IsWindowVisible(hwnd):
                    try:
                        window_title = win32gui.GetWindowText(hwnd)
                        class_name = win32gui.GetClassName(hwnd)
                        
                        # More specific Chrome detection
                        if ('Chrome' in window_title or 
                            'Chromium' in window_title or 
                            'Chrome_WidgetWin_1' in class_name or
                            'Chrome_RenderWidgetHostHWND' in class_name):
                            hwnds.append(hwnd)
                            logger.debug(f"Worker {self.worker_id}: Found Chrome window - Title: '{window_title}', Class: '{class_name}'")
                    except:
                        pass
                return True
            
            # Wait for window to be created (increased wait time for undetected-chromedriver)
            logger.debug(f"Worker {self.worker_id}: Waiting for Chrome window to initialize...")
            time.sleep(3)
            
            hwnds = []
            win32gui.EnumWindows(callback, hwnds)
            
            # Try multiple times if window not found immediately
            retry_count = 0
            while len(hwnds) == 0 and retry_count < 5:
                logger.debug(f"Worker {self.worker_id}: Chrome window not found, retry {retry_count + 1}/5...")
                time.sleep(1)
                hwnds = []
                win32gui.EnumWindows(callback, hwnds)
                retry_count += 1
            
            # Find our worker's window (newest Chrome window)
            if hwnds:
                self.browser_hwnd = hwnds[-1]
                
                logger.info(f"Worker {self.worker_id}: Found Chrome window (HWND: {self.browser_hwnd}), attempting to hide...")
                
                # Get extended window style
                ex_style = win32gui.GetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE)
                
                # Add WS_EX_TOOLWINDOW to hide from taskbar
                ex_style |= win32con.WS_EX_TOOLWINDOW
                
                # Remove WS_EX_APPWINDOW to ensure it's hidden
                ex_style &= ~win32con.WS_EX_APPWINDOW
                
                # Apply new style
                win32gui.SetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE, ex_style)
                
                # Hide the window first
                win32gui.ShowWindow(self.browser_hwnd, win32con.SW_HIDE)
                
                # Wait a bit
                time.sleep(0.5)
                
                # Move offscreen
                win32gui.SetWindowPos(
                    self.browser_hwnd,
                    None,
                    -32000, -32000,  # Far offscreen
                    100, 100,
                    win32con.SWP_NOACTIVATE | win32con.SWP_NOZORDER
                )
                
                # Show as minimized (but still hidden from taskbar due to style change)
                win32gui.ShowWindow(self.browser_hwnd, win32con.SW_SHOWMINIMIZED)
                
                logger.info(f"Worker {self.worker_id}: ✅ Browser hidden from taskbar (BAS-style)")
                self.is_hidden = True
            else:
                logger.warning(f"Worker {self.worker_id}: ⚠️ Could not find Chrome window after {retry_count + 1} attempts")
                logger.warning(f"Worker {self.worker_id}: Browser may still be visible in taskbar")
                self.is_hidden = False
        
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: ❌ Error hiding from taskbar - {e}")
            import traceback
            logger.debug(traceback.format_exc())
            self.is_hidden = False
    
    def _show_browser(self):
        """Show browser window (restore from hidden state)"""
        if not WIN32_AVAILABLE or not self.browser_hwnd:
            logger.warning(f"Worker {self.worker_id}: Cannot show browser - no window handle")
            return
        
        try:
            # Get extended window style
            ex_style = win32gui.GetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE)
            
            # Remove WS_EX_TOOLWINDOW
            ex_style &= ~win32con.WS_EX_TOOLWINDOW
            
            # Add WS_EX_APPWINDOW to show in taskbar
            ex_style |= win32con.WS_EX_APPWINDOW
            
            # Apply new style
            win32gui.SetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE, ex_style)
            
            # Restore window
            win32gui.ShowWindow(self.browser_hwnd, win32con.SW_RESTORE)
            
            # Move to visible position
            win32gui.SetWindowPos(
                self.browser_hwnd,
                win32con.HWND_TOP,
                100, 100,
                1200, 800,
                win32con.SWP_SHOWWINDOW
            )
            
            # Bring to front
            win32gui.SetForegroundWindow(self.browser_hwnd)
            
            logger.info(f"Worker {self.worker_id}: ✅ Browser shown")
            self.is_hidden = False
        
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: ❌ Could not show browser - {e}")
    
    def _hide_browser(self):
        """Hide browser window again"""
        if not WIN32_AVAILABLE or not self.browser_hwnd:
            logger.warning(f"Worker {self.worker_id}: Cannot hide browser - no window handle")
            return
        
        try:
            # Get extended window style
            ex_style = win32gui.GetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE)
            
            # Add WS_EX_TOOLWINDOW
            ex_style |= win32con.WS_EX_TOOLWINDOW
            
            # Remove WS_EX_APPWINDOW
            ex_style &= ~win32con.WS_EX_APPWINDOW
            
            # Apply new style
            win32gui.SetWindowLong(self.browser_hwnd, win32con.GWL_EXSTYLE, ex_style)
            
            # Hide window
            win32gui.ShowWindow(self.browser_hwnd, win32con.SW_HIDE)
            
            # Move offscreen
            win32gui.SetWindowPos(
                self.browser_hwnd,
                None,
                -32000, -32000,
                100, 100,
                win32con.SWP_NOACTIVATE
            )
            
            logger.info(f"Worker {self.worker_id}: ✅ Browser hidden")
            self.is_hidden = True
        
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: ❌ Could not hide browser - {e}")
    
    def toggle_visibility(self):
        """Toggle browser visibility (for GUI button)"""
        if self.is_hidden:
            self._show_browser()
        else:
            self._hide_browser()
    
    def setup_driver(self, proxy: str = None) -> bool:
        """
        Setup Chrome driver dengan full features - ADVANCED ANTI-DETECTION
        Now with Undetected Chrome & AI optimization
        
        Args:
            proxy: Proxy string (optional)
        
        Returns:
            True jika sukses setup driver
        """
        try:
            # Parse proxy
            if proxy:
                self.proxy = proxy
                self.parse_proxy(proxy)
            
            # Load fingerprint
            self.load_fingerprint()
            
            # Check if using undetected chrome
            use_undetected = getattr(config, 'USE_UNDETECTED_CHROME', True) and UNDETECTED_AVAILABLE
            
            if use_undetected:
                logger.info(f"Worker {self.worker_id}: Using Undetected ChromeDriver (Advanced Bypass)")
                return self._setup_undetected_driver()
            else:
                logger.info(f"Worker {self.worker_id}: Using Standard Selenium")
                return self._setup_standard_driver()
                
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: Browser setup failed - {e}")
            return False
    
    def _setup_undetected_driver(self) -> bool:
        """Setup with undetected-chromedriver (BEST for bypass)"""
        try:
            options = uc.ChromeOptions()
            
            # Basic stealth options
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--no-sandbox')
            
            # Start minimized (for BAS-style hiding)
            options.add_argument('--start-minimized')
            
            # User agent
            ua_mode = getattr(config, 'USER_AGENT_MODE', 'Mixed')
            if self.fingerprint_data:
                ua = self.fingerprint_data.get('navigator', {}).get('userAgent')
                if ua:
                    options.add_argument(f'--user-agent={ua}')
            elif ua_mode == "Mobile Only":
                options.add_argument('--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15')
            
            # Headless (only if explicitly enabled)
            if getattr(config, 'HEADLESS', False):
                options.add_argument('--headless=new')
            
            # Proxy setup (without auth for undetected - will handle separately)
            if self.proxy and not self.has_auth:
                options.add_argument(f'--proxy-server={self.proxy}')
            
            # Create driver with undetected-chromedriver
            self.driver = uc.Chrome(options=options, version_main=None, use_subprocess=True)
            
            # Additional stealth scripts
            self._inject_stealth_scripts()
            
            # BAS-Style: Hide from taskbar
            self._hide_browser_from_taskbar()
            
            self.is_running = True
            
            logger.info(f"Worker {self.worker_id}: Undetected ChromeDriver setup successful!")
            return True
            
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: Undetected setup failed - {e}")
            return False
    
    def _setup_standard_driver(self) -> bool:
        """Setup with standard Selenium (fallback)"""
        try:
            options = Options()
            
            # All stealth options
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_argument("--disable-infobars")
            options.add_argument("--disable-notifications")
            options.add_argument("--disable-popup-blocking")
            options.add_argument("--no-first-run")
            options.add_argument("--no-service-autorun")
            options.add_argument("--password-store=basic")
            options.add_argument("--start-minimized")
            
            options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
            options.add_experimental_option('useAutomationExtension', False)
            
            # User agent
            ua_mode = getattr(config, 'USER_AGENT_MODE', 'Mixed')
            if self.fingerprint_data:
                ua = self.fingerprint_data.get('navigator', {}).get('userAgent')
                if ua:
                    options.add_argument(f'--user-agent={ua}')
            elif ua_mode == "Mobile Only":
                options.add_experimental_option("mobileEmulation", {"deviceName": "iPhone 12 Pro"})
            elif ua_mode == "Desktop Only":
                options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36')
            else:  # Mixed
                if random.random() < 0.7:
                    options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36')
                else:
                    options.add_experimental_option("mobileEmulation", {"deviceName": "iPhone 12 Pro"})
            
            # Headless
            if getattr(config, 'HEADLESS', False):
                options.add_argument("--headless=new")
                options.add_argument("--disable-gpu")
            
            # Proxy with auth
            if self.proxy:
                if self.has_auth:
                    plugin_file = self.create_proxy_extension()
                    if plugin_file:
                        options.add_extension(plugin_file)
                else:
                    proxy_type = getattr(config, 'PROXY_TYPE', 'http')
                    if proxy_type == 'auto':
                        proxy_type = 'http'
                    options.add_argument(f'--proxy-server={proxy_type}://{self.proxy_host}:{self.proxy_port}')
            
            # Create driver
            driver_path = os.path.join(os.getcwd(), 'chromedriver.exe')
            if os.path.exists(driver_path):
                service = Service(driver_path)
                self.driver = webdriver.Chrome(service=service, options=options)
            else:
                try:
                    from webdriver_manager.chrome import ChromeDriverManager
                    service = Service(ChromeDriverManager().install())
                    self.driver = webdriver.Chrome(service=service, options=options)
                except Exception as e:
                    logger.error(f"Worker {self.worker_id}: Webdriver-manager failed - {e}")
                    return False
            
            # Inject stealth scripts
            self._inject_stealth_scripts()
            
            # Apply selenium-stealth if available
            try:
                from selenium_stealth import stealth
                stealth(self.driver,
                    languages=["en-US", "en"],
                    vendor="Google Inc.",
                    platform="Win32",
                    webgl_vendor="Intel Inc.",
                    renderer="Intel Iris OpenGL Engine",
                    fix_hairline=True)
                logger.info(f"Worker {self.worker_id}: Selenium-stealth applied")
            except ImportError:
                pass
            
            # BAS-Style: Hide from taskbar
            self._hide_browser_from_taskbar()
            
            # Cleanup proxy plugin
            if self.has_auth:
                try:
                    plugin_file = f"proxy_auth_plugin_{self.worker_id}.zip"
                    if os.path.exists(plugin_file):
                        os.remove(plugin_file)
                except:
                    pass
            
            self.is_running = True
            
            logger.info(f"Worker {self.worker_id}: Standard browser setup successful!")
            return True
            
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: Standard setup failed - {e}")
            return False
    
    def _inject_stealth_scripts(self):
        """Inject advanced stealth scripts"""
        try:
            # Advanced stealth via CDP
            self.driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                'source': '''
                    // Hide webdriver
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    
                    // Add fake plugins
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3, 4, 5]
                    });
                    
                    // Set languages
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                    
                    // Add chrome object
                    window.chrome = {
                        runtime: {},
                        loadTimes: function() {},
                        csi: function() {},
                        app: {}
                    };
                    
                    // Override permissions
                    const originalQuery = window.navigator.permissions.query;
                    window.navigator.permissions.query = (parameters) => (
                        parameters.name === 'notifications' ?
                        Promise.resolve({ state: Notification.permission }) :
                        originalQuery(parameters)
                    );
                '''
            })
            
            # WebRTC protection
            if getattr(config, 'WEBRTC_ENABLED', True):
                try:
                    self.driver.execute_cdp_cmd('Network.enable', {})
                except:
                    pass
            
            # Timezone sync
            if getattr(config, 'TIMEZONE_SYNC', True):
                try:
                    self.driver.execute_cdp_cmd('Emulation.setTimezoneOverride', {
                        'timezoneId': 'Asia/Jakarta'
                    })
                except:
                    pass
                    
        except Exception as e:
            logger.debug(f"Worker {self.worker_id}: Stealth injection warning - {e}")
    
    def detect_captcha(self) -> bool:
        """
        Detect if captcha is present on current page
        Enhanced with AI pattern learning
        
        Returns:
            True jika captcha terdeteksi
        """
        try:
            if not self.driver or not self.is_running:
                return False
            
            current_url = self.driver.current_url.lower()
            page_title = self.driver.title.lower()
            
            # AI-based detection first (if available)
            if AI_AVAILABLE and getattr(config, 'AUTO_CAPTCHA_LEARN', True):
                if ai_engine.is_likely_captcha(current_url, page_title):
                    logger.warning(f"Worker {self.worker_id}: CAPTCHA detected by AI pattern matching!")
                    return True
            
            # URL-based detection
            captcha_domains = [
                'appslime.com',
                'popzone',
                'captcha',
                'verify',
                'challenge',
                'protection',
                'cloudflare',
                'recaptcha',
                'hcaptcha',
                'funcaptcha'
            ]
            
            for domain in captcha_domains:
                if domain in current_url:
                    logger.warning(f"Worker {self.worker_id}: Captcha redirect detected ({domain})")
                    
                    # Learn this pattern with AI
                    if AI_AVAILABLE and getattr(config, 'AUTO_CAPTCHA_LEARN', True):
                        try:
                            page_source = self.driver.page_source
                            ai_engine.learn_captcha_pattern(current_url, page_title, page_source)
                        except:
                            pass
                    
                    return True
            
            # Title-based detection
            captcha_titles = [
                'captcha',
                'verification',
                'challenge',
                'just a moment',
                'checking your browser',
                'attention required'
            ]
            
            for title in captcha_titles:
                if title in page_title:
                    logger.warning(f"Worker {self.worker_id}: Captcha page title detected ({title})")
                    return True
            
            # Element-based detection
            recaptcha_frames = self.driver.find_elements(By.CSS_SELECTOR, "iframe[src*='recaptcha'], iframe[src*='google.com/recaptcha']")
            if recaptcha_frames:
                logger.warning(f"Worker {self.worker_id}: reCAPTCHA iframe detected")
                return True
            
            hcaptcha_frames = self.driver.find_elements(By.CSS_SELECTOR, "iframe[src*='hcaptcha']")
            if hcaptcha_frames:
                logger.warning(f"Worker {self.worker_id}: hCaptcha iframe detected")
                return True
            
            cloudflare_elements = self.driver.find_elements(By.CSS_SELECTOR, "#challenge-running, .challenge-running, #cf-wrapper")
            if cloudflare_elements:
                logger.warning(f"Worker {self.worker_id}: Cloudflare challenge detected")
                return True
            
            # Text-based detection
            try:
                page_text = self.driver.page_source.lower()
                captcha_keywords = [
                    'i am not a robot',
                    'prove you are not a robot',
                    'verify you are human',
                    'complete the captcha',
                    'solve the puzzle',
                    'press and hold',
                    'click to verify',
                    'security check'
                ]
                
                for keyword in captcha_keywords:
                    if keyword in page_text:
                        logger.warning(f"Worker {self.worker_id}: Captcha text detected ({keyword})")
                        return True
            except:
                pass
            
            return False
            
        except Exception as e:
            logger.debug(f"Worker {self.worker_id}: Captcha detection error - {e}")
            return False
    
    def bypass_checkbox_captcha(self) -> bool:
        """
        Bypass simple checkbox CAPTCHA (appslime/popzone style) with human-like behavior
        
        Returns:
            True if bypass successful
        """
        try:
            logger.info(f"Worker {self.worker_id}: 🎯 Attempting checkbox CAPTCHA bypass...")
            
            # Wait for page to fully load
            time.sleep(random.uniform(2, 4))
            
            # Try multiple selectors for checkbox
            checkbox_selectors = [
                "input[type='checkbox']",
                "input[id*='robot']",
                "input[id*='captcha']",
                "input[name*='robot']",
                "label input",
                ".captcha-checkbox input",
                "#captcha-checkbox",
                "input[id*='not-robot']",
                "input[id*='human']"
            ]
            
            checkbox = None
            for selector in checkbox_selectors:
                try:
                    checkboxes = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if checkboxes:
                        for cb in checkboxes:
                            if cb.is_displayed() and cb.is_enabled():
                                checkbox = cb
                                logger.info(f"Worker {self.worker_id}: ✅ Found checkbox with selector: {selector}")
                                break
                        if checkbox:
                            break
                except:
                    continue
            
            if not checkbox:
                logger.warning(f"Worker {self.worker_id}: ⚠️ Checkbox not found")
                return False
            
            # Human-like behavior: scroll into view
            self.driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", checkbox)
            time.sleep(random.uniform(1, 2))
            
            # Human-like behavior: move mouse (via JavaScript hover simulation)
            self.driver.execute_script("""
                var element = arguments[0];
                var event = new MouseEvent('mouseover', {
                    'view': window,
                    'bubbles': true,
                    'cancelable': true
                });
                element.dispatchEvent(event);
            """, checkbox)
            
            # Wait like human reading
            time.sleep(random.uniform(1.5, 3))
            
            # Try clicking with ActionChains (more human-like)
            try:
                actions = ActionChains(self.driver)
                actions.move_to_element(checkbox)
                actions.pause(random.uniform(0.3, 0.7))
                actions.click()
                actions.perform()
                logger.info(f"Worker {self.worker_id}: ✅ Clicked checkbox with ActionChains")
            except:
                # Fallback: JavaScript click
                self.driver.execute_script("arguments[0].click();", checkbox)
                logger.info(f"Worker {self.worker_id}: ✅ Clicked checkbox with JavaScript")
            
            # Wait for CAPTCHA to process
            time.sleep(random.uniform(2, 4))
            
            # Check if CAPTCHA is gone
            if not self.detect_captcha():
                logger.info(f"Worker {self.worker_id}: 🎉 Checkbox CAPTCHA bypassed successfully!")
                return True
            else:
                logger.warning(f"Worker {self.worker_id}: ⚠️ Checkbox clicked but CAPTCHA still present")
                return False
                
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: ❌ Checkbox CAPTCHA bypass error - {e}")
            return False
    
    def solve_captcha(self) -> bool:
        """
        Attempt to solve CAPTCHA using configured method
        
        Returns:
            True if captcha solved successfully
        """
        try:
            solver_enabled = getattr(config, 'CAPTCHA_SOLVER_ENABLED', False)
            
            if not solver_enabled:
                logger.warning(f"Worker {self.worker_id}: CAPTCHA detected but solver disabled")
                return False
            
            solver_service = getattr(config, 'CAPTCHA_SOLVER_SERVICE', '2captcha')
            api_key = getattr(config, 'CAPTCHA_API_KEY', '')
            
            if not api_key:
                logger.error(f"Worker {self.worker_id}: CAPTCHA solver enabled but no API key provided")
                return False
            
            logger.info(f"Worker {self.worker_id}: Attempting to solve CAPTCHA with {solver_service}...")
            
            # Try to solve with API
            if solver_service in ['2captcha', 'anticaptcha']:
                return self._solve_captcha_with_api(api_key, solver_service)
            
            return False
            
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: CAPTCHA solving failed - {e}")
            return False
    
    def _solve_captcha_with_api(self, api_key: str, service: str) -> bool:
        """Solve captcha using 2captcha or anticaptcha API"""
        try:
            from python_anticaptcha import AnticaptchaClient, NoCaptchaTaskProxylessTask
            
            # Get site key
            site_key = self.driver.execute_script("""
                let el = document.querySelector('[data-sitekey]');
                return el ? el.getAttribute('data-sitekey') : null;
            """)
            
            if not site_key:
                logger.error(f"Worker {self.worker_id}: No captcha site key found")
                return False
            
            # Solve via API
            client = AnticaptchaClient(api_key)
            task = NoCaptchaTaskProxylessTask(
                website_url=self.driver.current_url,
                website_key=site_key
            )
            
            job = client.createTask(task)
            logger.info(f"Worker {self.worker_id}: Waiting for CAPTCHA solution...")
            job.join(maximum_time=120)
            
            response = job.get_solution_response()
            
            # Inject solution
            self.driver.execute_script(f"""
                document.getElementById('g-recaptcha-response').innerHTML = '{response}';
                if (typeof onCaptchaSuccess === 'function') {{
                    onCaptchaSuccess('{response}');
                }}
            """)
            
            # Try to submit form
            try:
                self.driver.execute_script("document.querySelector('form').submit();")
            except:
                pass
            
            time.sleep(3)
            
            # Check if still captcha
            if not self.detect_captcha():
                logger.info(f"Worker {self.worker_id}: ✅ CAPTCHA solved successfully!")
                return True
            else:
                logger.warning(f"Worker {self.worker_id}: CAPTCHA solution failed")
                return False
                
        except Exception as e:
            logger.error(f"Worker {self.worker_id}: API captcha solving error - {e}")
            return False
    
    def human_scroll(self, scroll_count: int = None):
        """
        Scroll dengan behavior seperti manusia
        
        Args:
            scroll_count: Jumlah scroll (optional, akan use AI-optimized jika None)
        """
        try:
            if not self.driver or not self.is_running:
                return
            
            # Get scroll count
            if scroll_count is None:
                if self.ai_scroll_count:
                    scroll_count = self.ai_scroll_count
                else:
                    scroll_count = random.randint(
                        getattr(config, 'SCROLL_MIN', 30),
                        getattr(config, 'SCROLL_MAX', 60)
                    )
            
            mouse_style = getattr(config, 'MOUSE_STYLE', 'Human Curves')
            
            for i in range(scroll_count):
                if not self.driver or not self.is_running:
                    break
                
                try:
                    if mouse_style == "Human Curves":
                        scroll_amount = random.randint(200, 600)
                        self.driver.execute_script(f"window.scrollBy({{top: {scroll_amount}, behavior: 'smooth'}});")
                        time.sleep(random.uniform(0.8, 2.5))
                    else:
                        scroll_amount = random.randint(300, 800)
                        self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
                        time.sleep(random.uniform(0.5, 1.5))
                    
                    if random.random() < 0.3:
                        time.sleep(random.uniform(1, 3))
                except:
                    break
            
            logger.debug(f"Worker {self.worker_id}: Scrolled {scroll_count} times")
            
        except Exception as e:
            if 'invalid session id' not in str(e).lower() and 'NoneType' not in str(e):
                logger.error(f"Worker {self.worker_id}: Scroll error - {e}")
    
    def simulate_reading(self, reading_time: float = None):
        """
        Simulate reading dengan delay
        
        Args:
            reading_time: Waktu baca dalam detik (optional, akan use AI-optimized jika None)
        """
        try:
            if not self.driver or not self.is_running:
                return
            
            # Get reading time
            if reading_time is None:
                if self.ai_delay:
                    reading_time = self.ai_delay
                else:
                    reading_time = random.uniform(
                        getattr(config, 'DELAY_MIN', 20),
                        getattr(config, 'DELAY_MAX', 30)
                    )
            
            logger.debug(f"Worker {self.worker_id}: Reading for {reading_time:.1f}s")
            time.sleep(reading_time)
            
        except Exception as e:
            if 'invalid session id' not in str(e).lower():
                logger.error(f"Worker {self.worker_id}: Reading simulation error - {e}")
    
    def execute_task(self, url: str, proxies: list = None) -> bool:
        """
        Execute single task dengan full human behavior + AI + CAPTCHA bypass + DEEP NAVIGATION
        
        Args:
            url: Target URL
            proxies: List of available proxies
        
        Returns:
            True jika task berhasil
        """
        start_time = time.time()
        proxy_used = None
        
        try:
            # AI-based proxy selection
            if proxies and len(proxies) > 0:
                if AI_AVAILABLE:
                    proxy = ai_engine.select_best_proxy(proxies)
                else:
                    proxy = random.choice(proxies)
                proxy_used = proxy
                logger.info(f"Worker {self.worker_id}: Selected proxy {proxy}")
            else:
                proxy = None
                logger.info(f"Worker {self.worker_id}: Running without proxy")
            
            # Get AI-optimized behavior
            if AI_AVAILABLE and getattr(config, 'AI_ENABLED', True):
                optimal_behavior = ai_engine.get_optimal_behavior()
                self.ai_scroll_count = int(optimal_behavior.get('scroll_count', 45))
                self.ai_delay = optimal_behavior.get('delay', 25)
                
                # Get AI-optimized CTR
                if getattr(config, 'AI_PREDICT_CTR', True):
                    self.ai_ctr = ai_engine.get_optimal_ctr(self.ai_scroll_count, self.ai_delay)
                    logger.info(f"Worker {self.worker_id}: AI optimized - scroll={self.ai_scroll_count}, delay={self.ai_delay}s, CTR={self.ai_ctr:.1f}%")
            
            # Setup browser
            logger.info(f"Worker {self.worker_id}: Setting up browser...")
            if not self.setup_driver(proxy):
                return False
            
            # Visit URL
            logger.info(f"Worker {self.worker_id}: Visiting {url}")
            self.driver.get(url)
            
            time.sleep(random.uniform(3, 5))
            
            # CAPTCHA detection & bypass
            captcha_bypassed = False
            
            if self.detect_captcha():
                self.captcha_detected_count += 1
                logger.error(f"Worker {self.worker_id}: ⚠️ CAPTCHA DETECTED! (Total: {self.captcha_detected_count})")
                logger.error(f"Worker {self.worker_id}: Captcha URL: {self.driver.current_url}")
                
                # Try checkbox bypass first (for simple CAPTCHAs)
                if self.bypass_checkbox_captcha():
                    logger.info(f"Worker {self.worker_id}: 🎉 Simple CAPTCHA bypassed!")
                    captcha_bypassed = True
                else:
                    # Try API solver as fallback
                    max_retry = getattr(config, 'CAPTCHA_MAX_RETRY', 3)
                    bypassed_with_api = False
                    
                    for retry in range(max_retry):
                        if self.solve_captcha():
                            logger.info(f"Worker {self.worker_id}: ✅ CAPTCHA bypassed successfully!")
                            captcha_bypassed = True
                            bypassed_with_api = True
                            break
                        else:
                            if retry < max_retry - 1:
                                logger.warning(f"Worker {self.worker_id}: Retry {retry+1}/{max_retry}...")
                                time.sleep(5)
                    
                    if not bypassed_with_api:
                        logger.error(f"Worker {self.worker_id}: ❌ Failed to bypass CAPTCHA after {max_retry} attempts")
                        
                        # Update proxy performance (failed)
                        if AI_AVAILABLE and proxy_used:
                            ai_engine.update_proxy_performance(proxy_used, False, 99999)
                        
                        return False
            else:
                logger.info(f"Worker {self.worker_id}: ✅ No captcha detected, proceeding...")
                captcha_bypassed = True
            
            # Wait a bit after CAPTCHA bypass for page to load
            if captcha_bypassed and self.captcha_detected_count > 0:
                logger.info(f"Worker {self.worker_id}: ⏳ Waiting for page to load after CAPTCHA bypass...")
                time.sleep(random.uniform(3, 5))
            
            # ==================================================================
            # DEEP NAVIGATION: Navigate through multiple pages
            # ==================================================================
            
            deep_nav_enabled = getattr(config, 'DEEP_NAVIGATION_ENABLED', True)
            
            if deep_nav_enabled and DEEP_NAV_AVAILABLE:
                logger.info(f"Worker {self.worker_id}: 🌊 Starting DEEP NAVIGATION mode...")
                
                # Initialize Deep Navigation Engine
                self.deep_nav = DeepNavigationEngine(self.driver, config)
                self.deep_nav.initialize(self.driver.current_url)
                
                # Navigate through pages with depth levels
                while self.deep_nav.should_navigate_deeper():
                    current_depth = self.deep_nav.current_depth
                    
                    # Get behavior untuk current depth
                    behavior = self.deep_nav.get_behavior_for_depth(current_depth)
                    
                    scroll_count = random.randint(behavior['scroll_min'], behavior['scroll_max'])
                    read_time = random.uniform(behavior['read_min'], behavior['read_max'])
                    
                    logger.info(f"Worker {self.worker_id}: 📄 Depth {current_depth} - Scroll {scroll_count}x, Read {read_time:.1f}s")
                    
                    # Human-like behavior pada current page
                    self.human_scroll(scroll_count)
                    self.simulate_reading(read_time)
                    
                    # Find dan klik link berikutnya
                    next_link = self.deep_nav.find_best_link()
                    
                    if next_link:
                        logger.info(f"Worker {self.worker_id}: 🔗 Navigating to next page (depth {current_depth} → {current_depth + 1})...")
                        
                        if self.deep_nav.navigate_to_link(next_link):
                            # Wait for new page to load
                            time.sleep(random.uniform(2, 4))
                        else:
                            logger.warning(f"Worker {self.worker_id}: ⚠️ Failed to navigate, stopping deep navigation")
                            break
                    else:
                        logger.info(f"Worker {self.worker_id}: ℹ️ No more valid links found, ending navigation")
                        break
                
                # Final page behavior
                final_depth = self.deep_nav.current_depth
                final_behavior = self.deep_nav.get_behavior_for_depth(final_depth)
                final_scroll = random.randint(final_behavior['scroll_min'], final_behavior['scroll_max'])
                final_read = random.uniform(final_behavior['read_min'], final_behavior['read_max'])
                
                logger.info(f"Worker {self.worker_id}: 📄 Final page (depth {final_depth}) - Scroll {final_scroll}x, Read {final_read:.1f}s")
                self.human_scroll(final_scroll)
                self.simulate_reading(final_read)
                
                # Get session summary
                summary = self.deep_nav.get_session_summary()
                logger.info(f"Worker {self.worker_id}: 🎉 Deep Navigation completed!")
                logger.info(f"Worker {self.worker_id}: 📊 Session Summary: {summary['pages_visited']} pages visited, max depth {summary['max_depth_reached']}")
                
            else:
                # ==================================================================
                # STANDARD MODE: Single page behavior (if deep nav disabled)
                # ==================================================================
                
                logger.info(f"Worker {self.worker_id}: 📜 Starting standard single-page behavior...")
                
                # Human-like behavior
                self.human_scroll()
                self.simulate_reading()
                
                # CTR simulation (AI-optimized)
                target_ctr = self.ai_ctr if self.ai_ctr else getattr(config, 'TARGET_CTR', 8.0)
                
                if random.random() * 100 < target_ctr:
                    try:
                        if not self.driver or not self.is_running:
                            return True
                        
                        links = self.driver.find_elements(By.TAG_NAME, 'a')
                        if links:
                            clickable_links = [l for l in links if l.is_displayed()]
                            if clickable_links:
                                link = random.choice(clickable_links)
                                self.driver.execute_script("arguments[0].scrollIntoView(true);", link)
                                time.sleep(random.uniform(0.5, 1.5))
                                link.click()
                                logger.info(f"Worker {self.worker_id}: ✅ Clicked a link (CTR simulation)")
                                time.sleep(random.uniform(2, 5))
                    except:
                        pass
                
                # Random extra scroll
                if random.random() < 0.5:
                    self.human_scroll()
            
            # Calculate latency
            latency = (time.time() - start_time) * 1000
            
            # Update proxy performance with AI
            if AI_AVAILABLE and proxy_used:
                ai_engine.update_proxy_performance(proxy_used, True, latency)
            
            logger.info(f"Worker {self.worker_id}: ✅ Task completed successfully! (Latency: {latency:.0f}ms)")
            return True
            
        except Exception as e:
            latency = (time.time() - start_time) * 1000
            
            # Update proxy performance (failed)
            if AI_AVAILABLE and proxy_used:
                ai_engine.update_proxy_performance(proxy_used, False, latency)
            
            if '[ERR_PROXY_CONNECTION_FAILED]' in str(e):
                logger.error(f"Worker {self.worker_id}: ❌ Proxy connection failed - proxy might be dead")
            elif 'invalid session id' not in str(e).lower():
                logger.error(f"Worker {self.worker_id}: ❌ Task failed - {e}")
            
            return False
            
        finally:
            self.stop()
    
    def stop(self):
        """Stop worker and cleanup"""
        self.is_running = False
        
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
            self.browser_hwnd = None
        
        # Cleanup proxy extension
        if self.has_auth:
            try:
                plugin_file = f"proxy_auth_plugin_{self.worker_id}.zip"
                if os.path.exists(plugin_file):
                    os.remove(plugin_file)
            except:
                pass
        
        # Cleanup deep nav
        self.deep_nav = None
