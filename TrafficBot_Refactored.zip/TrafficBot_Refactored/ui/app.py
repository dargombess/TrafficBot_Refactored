"""
ui/app.py - PROFESSIONAL EDITION (COMPLETE OPTIMIZED)
Dashboard + Settings dengan PRO Tab Design & Complete Features
Window: 1200x750 | Worker Monitor: 6 cards per row | All Menus Included
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import threading

from ui.styles import *
from ui.components import *
from ui.advanced_settings import AdvancedSettingsPanel
from bot_config import config
from orchestrator import orchestrator
from core.resource_manager import resource_manager


class TrafficBotGUI(tk.Tk):
    """Main GUI Application - Professional Edition with Complete Features"""
    
    def __init__(self):
        super().__init__()
        
        self.title("Traffic Bot - Professional Edition")
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.minsize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
        self.configure(bg=COLOR_BG_MAIN)
        
        # Grid configuration
        self.grid_columnconfigure(0, weight=0, minsize=SIDEBAR_WIDTH)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # State variables
        self.is_running = False
        self.worker_cards = {}
        self.stat_cards = {}
        self.current_page = "dashboard"
        self.pages = {}
        
        # Create UI
        self._create_sidebar()
        self._create_pages_container()
        self._create_dashboard_page()
        self._create_settings_page()
        self._show_page("dashboard")
        
        # Setup callbacks
        orchestrator.set_status_callback(self._on_status_change)
        orchestrator.set_worker_callback(self._on_worker_update)
        self._start_stats_update()
        
        # Window close handler
        self.protocol("WM_DELETE_WINDOW", self._on_close)
    
    def _bind_mousewheel(self, widget, canvas):
        """Bind mouse wheel to canvas for scrolling"""
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        def on_mousewheel_linux(event):
            if event.num == 5:
                canvas.yview_scroll(1, "units")
            elif event.num == 4:
                canvas.yview_scroll(-1, "units")
        
        def on_enter(event):
            widget.bind_all("<MouseWheel>", on_mousewheel)
            widget.bind_all("<Button-4>", on_mousewheel_linux)
            widget.bind_all("<Button-5>", on_mousewheel_linux)
        
        def on_leave(event):
            widget.unbind_all("<MouseWheel>")
            widget.unbind_all("<Button-4>")
            widget.unbind_all("<Button-5>")
        
        widget.bind('<Enter>', on_enter)
        widget.bind('<Leave>', on_leave)
    
    def _create_sidebar(self):
        """Create left sidebar with navigation"""
        sidebar = SharpPanel(self, width=SIDEBAR_WIDTH)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)
        
        # Header
        tk.Label(sidebar, text="TRAFFIC BOT", font=(FONT_FAMILY_PRIMARY, 16, "bold"),
                 bg=COLOR_BG_PANEL, fg=COLOR_ACCENT_CYAN).pack(pady=(20, 3))
        tk.Label(sidebar, text="Professional Edition", font=(FONT_FAMILY_PRIMARY, 9),
                 bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY).pack(pady=(0, 20))
        
        # Navigation buttons
        self.btn_dashboard = Bevel3DButton(sidebar, text="📊 DASHBOARD",
                                          command=lambda: self._show_page("dashboard"), 
                                          color=COLOR_ACCENT_CYAN, height=1)
        self.btn_dashboard.pack(fill="x", padx=15, pady=3)
        
        self.btn_settings = Bevel3DButton(sidebar, text="⚙️ SETTINGS",
                                         command=lambda: self._show_page("settings"), 
                                         color=COLOR_BG_MAIN, height=1)
        self.btn_settings.pack(fill="x", padx=15, pady=3)
        
        tk.Frame(sidebar, bg=COLOR_BG_PANEL, height=15).pack()
        
        # Quick start section
        tk.Label(sidebar, text="QUICK START", font=(FONT_FAMILY_PRIMARY, 9, "bold"),
                 bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY).pack(pady=(5, 5))
        
        frame = tk.Frame(sidebar, bg=COLOR_BG_PANEL)
        frame.pack(fill="x", padx=15, pady=3)
        
        tk.Label(frame, text="Workers:", font=(FONT_FAMILY_PRIMARY, 10),
                 bg=COLOR_BG_PANEL, fg=COLOR_TEXT_SECONDARY).pack(side="left")
        
        self.entry_workers = tk.Entry(frame, font=(FONT_FAMILY_PRIMARY, 10),
                                      bg=COLOR_INPUT_BG, fg=COLOR_TEXT_PRIMARY, 
                                      relief="flat", width=6)
        self.entry_workers.insert(0, "50")
        self.entry_workers.pack(side="right")
        
        # Start/Stop button
        self.btn_start = Bevel3DButton(sidebar, text="🚀 START ENGINE",
                                      command=self._toggle_bot, color=COLOR_SUCCESS, height=1)
        self.btn_start.pack(side="bottom", fill="x", padx=15, pady=15)
    
    def _create_pages_container(self):
        """Create container for pages"""
        self.pages_container = tk.Frame(self, bg=COLOR_BG_MAIN)
        self.pages_container.grid(row=0, column=1, sticky="nsew")
    
    def _create_dashboard_page(self):
        """Create dashboard page with stats, worker monitor, and logs"""
        page = tk.Frame(self.pages_container, bg=COLOR_BG_MAIN)
        
        # ========== STATS CARDS ==========
        stats_frame = SharpPanel(page)
        stats_frame.pack(fill="x", padx=15, pady=(15, 10))
        
        for i in range(4):
            stats_frame.grid_columnconfigure(i, weight=1)
        
        stats = [
            ("SUCCESS", "0", COLOR_SUCCESS),
            ("FAILED", "0", COLOR_ACCENT_RED),
            ("ACTIVE", "0", COLOR_ACCENT_CYAN),
            ("BLOCKED", "0", COLOR_WARNING)
        ]
        
        for i, (label, value, color) in enumerate(stats):
            card = StatCard(stats_frame, label, value, color)
            card.grid(row=0, column=i, padx=8, pady=10, sticky="ew")
            self.stat_cards[label.lower()] = card
        
        # ========== WORKER MONITOR ==========
        monitor_panel = SharpPanel(page, height=260)
        monitor_panel.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        monitor_panel.pack_propagate(False)
        
        tk.Label(monitor_panel, text="WORKER MONITOR", font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                 bg=COLOR_BG_PANEL, fg=COLOR_TEXT_PRIMARY).pack(pady=(10, 8))
        
        # Scrollable worker grid
        canvas = tk.Canvas(monitor_panel, bg=COLOR_BG_PANEL, highlightthickness=0)
        scrollbar = tk.Scrollbar(monitor_panel, orient="vertical", command=canvas.yview)
        self.worker_grid_frame = tk.Frame(canvas, bg=COLOR_BG_PANEL)
        
        canvas.create_window((0, 0), window=self.worker_grid_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True, padx=12, pady=(0, 12))
        scrollbar.pack(side="right", fill="y")
        
        # Configure grid columns (6 per row)
        for i in range(6):
            self.worker_grid_frame.grid_columnconfigure(i, weight=1, minsize=150)
        
        # Create 50 worker cards
        for i in range(50):
            card = WorkerCard(self.worker_grid_frame, i + 1, self._on_worker_click)
            card.grid(row=i//6, column=i%6, padx=4, pady=4, sticky="ew")
            self.worker_cards[i + 1] = card
        
        # Update scroll region
        self.worker_grid_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))
        self._bind_mousewheel(canvas, canvas)
        
        # ========== EVENT LOGS ==========
        log_panel = SharpPanel(page, height=250)
        log_panel.pack(fill="both", padx=15, pady=(0, 15))
        log_panel.pack_propagate(False)
        
        tk.Label(log_panel, text="EVENT LOGS", font=(FONT_FAMILY_PRIMARY, 12, "bold"),
                 bg=COLOR_BG_PANEL, fg=COLOR_TEXT_PRIMARY).pack(pady=(10, 8))
        
        self.log_console = ConsoleLog(log_panel)
        self.log_console.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.log_console.log("[SYSTEM] Traffic Bot Ready - Professional Edition")
        
        self.pages["dashboard"] = page
    
    def _create_settings_page(self):
        """Create settings page with professional tab-based panel"""
        page = tk.Frame(self.pages_container, bg=COLOR_BG_MAIN)
        
        # Use AdvancedSettingsPanel with PRO tabs
        self.advanced_panel = AdvancedSettingsPanel(page)
        self.advanced_panel.pack(fill="both", expand=True, padx=15, pady=15)
        
        self.pages["settings"] = page
    
    def _on_worker_click(self, worker_id):
        """Handle worker card click to toggle visibility"""
        if orchestrator.has_worker(worker_id):
            orchestrator.toggle_worker_visibility(worker_id)
            self.log_console.log(f"[WORKER #{worker_id}] Browser visibility toggled")
        else:
            self.log_console.log(f"[WARNING] Worker #{worker_id} is not active")
    
    def _show_page(self, page_name):
        """Show specified page and update navigation buttons"""
        for name, page in self.pages.items():
            if name == page_name:
                page.pack(fill="both", expand=True)
            else:
                page.pack_forget()
        
        self.current_page = page_name
        
        # Update button colors
        if page_name == "dashboard":
            self.btn_dashboard.config(bg=COLOR_ACCENT_CYAN)
            self.btn_settings.config(bg=COLOR_BG_MAIN)
        else:
            self.btn_dashboard.config(bg=COLOR_BG_MAIN)
            self.btn_settings.config(bg=COLOR_ACCENT_CYAN)
    
    def _toggle_bot(self):
        """Toggle bot start/stop"""
        if not self.is_running:
            self._start_bot()
        else:
            self._stop_bot()
    
    def _start_bot(self):
        """Start the bot with validation"""
        # Validate article file
        if not config.FILE_ARTICLES:
            messagebox.showerror("Error", "Please select article file in Settings (Files tab)!")
            self._show_page("settings")
            return
        
        # Validate worker count
        try:
            num = int(self.entry_workers.get())
            if num < 1 or num > 100:
                raise ValueError()
        except:
            messagebox.showerror("Error", "Workers must be between 1-100!")
            return
        
        # Update config and start
        config.TASK_COUNT = num
        self.is_running = True
        self.btn_start.config(text="⛔ STOP ENGINE", bg=COLOR_ACCENT_RED)
        self.log_console.log(f"[START] Launching {num} workers...")
        self.log_console.log(f"[CONFIG] Article File: {config.FILE_ARTICLES}")
        
        if config.FILE_PROXIES:
            self.log_console.log(f"[CONFIG] Proxy File: {config.FILE_PROXIES}")
        
        if getattr(config, "DEEP_NAVIGATION_ENABLED", False):
            self.log_console.log(f"[CONFIG] Deep Navigation: ENABLED (Depth: {getattr(config, 'MIN_PAGES', 2)}-{getattr(config, 'MAX_PAGES', 5)})")
        
        # Start in background thread
        threading.Thread(target=lambda: orchestrator.start(num), daemon=True).start()
    
    def _stop_bot(self):
        """Stop the bot"""
        self.log_console.log("[STOP] Stopping all workers...")
        self.is_running = False
        self.btn_start.config(text="🚀 START ENGINE", bg=COLOR_SUCCESS)
        
        # Stop in background thread
        threading.Thread(target=orchestrator.stop, daemon=True).start()
    
    def _on_status_change(self, status):
        """Callback from orchestrator for status updates"""
        if hasattr(self, 'log_console'):
            self.log_console.log(status)
    
    def _on_worker_update(self, worker_id, status, color, info=""):
        """Callback from orchestrator for worker card updates"""
        if worker_id in self.worker_cards:
            self.worker_cards[worker_id].update_status(status, color, info)
    
    def _start_stats_update(self):
        """Start periodic statistics update loop"""
        def loop():
            if self.is_running:
                stats = orchestrator.get_statistics()
                self.stat_cards['success'].update_value(stats.get('success_count', 0))
                self.stat_cards['failed'].update_value(stats.get('failed_count', 0))
                self.stat_cards['active'].update_value(stats.get('active_workers', 0))
                self.stat_cards['blocked'].update_value(stats.get('blacklisted_ips', 0))
            
            self.after(1000, loop)
        
        loop()
    
    def _on_close(self):
        """Handle window close event"""
        if self.is_running:
            if messagebox.askyesno("Exit Confirmation", 
                                  "Bot is currently running. Stop all workers and exit?"):
                self.log_console.log("[SYSTEM] Shutting down...")
                self._stop_bot()
                self.after(2000, self.destroy)
        else:
            self.destroy()


# ========== ENTRY POINT ==========
if __name__ == "__main__":
    app = TrafficBotGUI()
    app.mainloop()
